# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution.

## Credential Values

- Android keystore password: 59e223e20ad210e63a145e00c66e6ca8
- Android key alias: a9b7c7133ef1647db8e4196dd52f107d
- Android key password: 7a4d3eeaaf82210e34c181c2cb02760d
      