import React, { Component } from 'react';
import { Text, View, SafeAreaView } from 'react-native';

export default class AccountScreen extends Component {
	render() {
		return (
			<SafeAreaView style={{ flex: 1, backgroundColor: 'pink' }}>
				<Text> AccountScreen </Text>
			</SafeAreaView>
		);
	}
}
