import React, { Component } from 'react';
import { Text, View, Button } from 'react-native';
import ImagePicker from 'react-native-image-crop-picker';
import firebase from 'react-native-firebase';

export default class ImagePickerScreen extends Component {
	constructor(props) {
		super(props);
	}
	render() {
		return (
			<View>
				<Button
					title='Pick a image'
					onPress={() => {
						ImagePicker.openPicker({}).then(async (images) => {
							console.log(images);
						});
					}}
				/>

				<Button
					title='Open Camera'
					onPress={() => {
						ImagePicker.openCamera({
							width: 300,
							height: 400,
							cropping: true,
						}).then((image) => {
							console.log(image);
						});
					}}
				/>
			</View>
		);
	}
}
