import React, { Component } from 'react';
import { Text, View, Button } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';

export default class AsyncStorageScreen extends Component {
	render() {
		return (
			<View>
				<Text> textInComponent </Text>
				<Button
					title='Save to Async Storage'
					onPress={() => {
						const data = {
							username: 'admin',
							email: 'tungnt@softech.vn',
							roles: 'admin',
						};
						const jsonString = JSON.stringify(data);
						AsyncStorage.setItem('user', jsonString).then(() => {
							console.log('OK');
						});
					}}
				/>

				<Button
					title='Read from Async Storage'
					onPress={() => {
						AsyncStorage.getItem('user').then((jsonString) => {
							if (jsonString) {
								const data = JSON.parse(jsonString);
								console.log(data);
							}
						});
					}}
				/>
			</View>
		);
	}
}
