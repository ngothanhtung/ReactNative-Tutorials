import React, { Component } from 'react';
import { Text, View } from 'react-native';
import Photos from '../../../modules/GalleryModule/components/Photos';
export default class AlbumsScreen extends Component {
	render() {
		return <Photos />;
	}
}
