import { createStackNavigator } from 'react-navigation';
import LoginScreen from './screens/StacKScreens/LoginScreen';
import RegisterScreen from './screens/StacKScreens/RegisterScreen';
import AlbumsScreen from './screens/StacKScreens/AlbumsScreen';
import UploadFileScreen from './screens/StacKScreens/UploadFileScreen';
import ImagePickerScreen from './screens/StacKScreens/ImagePickerScreen';
import AnimationScreen from './screens/StacKScreens/AnimationScreen';
import AsyncStorageScreen from './screens/StacKScreens/AsyncStorageScreen';
import GoogleMapsScreen from './screens/StacKScreens/GoogleMapsScreen';

const RouteConfigs = {
	GoogleMapsScreen: { screen: GoogleMapsScreen },

	AsyncStorageScreen: { screen: AsyncStorageScreen },

	AnimationScreen: { screen: AnimationScreen },

	ImagePickerScreen: {
		screen: ImagePickerScreen,
		navigationOptions: ({ navigation }) => ({
			title: 'PICK A IMAGE OR OPEN CAMERA',
			header: null,
		}),
	},

	UploadFileScreen: {
		screen: UploadFileScreen,
		navigationOptions: ({ navigation }) => ({
			title: 'UPLOAD',
			header: null,
		}),
	},

	AlbumsScreen: {
		screen: AlbumsScreen,
		navigationOptions: ({ navigation }) => ({
			title: 'ALBUMS',
			header: null,
		}),
	},

	LoginScreen: {
		screen: LoginScreen,
		navigationOptions: ({ navigation }) => ({
			title: 'LOGIN',
			header: null,
		}),
	},

	RegisterScreen: {
		screen: RegisterScreen,
		navigationOptions: ({ navigation }) => ({
			title: 'REGISTER',
		}),
	},
};

const StackNavigatorConfig = {
	// initialRouteName: 'AnimationScreen',
	initialRouteParams: { message: 'Hello' },
	defaultNavigationOptions: {},
	mode: 'modal',
	// headerMode: 'none',
	// headerBackTitleVisible: false,
};

const stack = createStackNavigator(RouteConfigs, StackNavigatorConfig);
export default stack;
